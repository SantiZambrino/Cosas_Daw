<?php

sleep(3);
$salida = json_encode($_POST);

echo $salida;


?>